# Landing Page Project

## Table of Contents

* [Project description](#project)
* [Usage](#usage)
* [Dependencies](#dependencies)
* [Contribute](#contribute)





## Project description

This project aims to give you real-world scenarios of manipulating the DOM. The functionality you will be using serves two purposes: to prepare you for appending dynamically added data to the DOM, and to show you how javascript can improve the usability of an otherwise static site. This project barely touches the surface of what is possible, but it does use some incredibly common events, methods, and logic.

For this project, refactor and test as much as possible while you are building. You should figure for every piece of functionality you add, you will likely spend just as much time testing and refactoring your code. If it takes you 3 hours to figure out the logic, it should likely take you another 3 hours determining that you wrote the best code possible. As your skills improve, this process will feel more natural. Make sure to remove any debugging code from your final submission.

##Usage
The landing page presents the first opportunity to fully combine your skills in HTML, CSS, and JavaScript into a large project. Aside from solidifying your skills with these three technologies, you’ll discover how best to combine them in a complex application.

##Dependencies
>querySelectorAll, querySelector, createElement, setAttribute, textContent, classList.add, classList.remove, appendChild, addEventListener, forEach, getAttribute.
##Contribute
###sponsor
By Ahmed Rezk

##License
[GNU General Public License version 3](https://opensource.org/licenses/GPL-3.0)
