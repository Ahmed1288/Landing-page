/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/

const sections = document.querySelectorAll('section');
const ulist = document.querySelector('#navbar__list');
const navLi = document.querySelectorAll('nav .navbar__list li');


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/
function respondToTheClick(e){
		e.preventDefault();
	// Scroll to anchor ID using scrollTop event
			$('html,body').animate({
				scrollTop:$($.attr(this,'href')).offset().top},1000);
	}



/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/
for (let a=1; a<=sections.length; a++){
	
	// build the nav
	
	const list=document.createElement('li');
	
	const clasu = "section"+a;
	list.classList.add(clasu);
	list.classList.add("menu__link");
	// Build menu 
	const aLink = document.createElement('a');
	aLink.setAttribute('href','#section'+a);
	aLink.textContent="Section "+a;
	aLink.classList.add("menu__alink");
	// Scroll to section on link click
	aLink.addEventListener('click',respondToTheClick);
	list.appendChild(aLink);
	ulist.appendChild(list);
	
	
}


window.addEventListener('scroll',()=>{
	
	let current = '';
	sections.forEach( section => {
		const sectionTop = section.offsetTop;
		const sectionHeight = section.clientHeight;
		section.classList.remove('your-active-class');
		// Set sections as active
		if(pageYOffset>=(sectionTop-sectionHeight/3)){
			
			current=section.getAttribute('id');
			
			// Add class 'your-active-class' to section when near top of viewport
			section.classList.add('your-active-class');
			section.previousElementSibling.classList.remove('your-active-class');
		}else{
			section.classList.remove('your-active-class');
		}
	})
	
	
})


/**
 * End Main Functions
 * 
*/








